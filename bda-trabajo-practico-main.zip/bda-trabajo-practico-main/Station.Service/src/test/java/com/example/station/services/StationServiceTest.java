package com.example.station.services;

import com.example.station.dtos.StationDto;
import com.example.station.models.Station;
import com.example.station.repositories.StationRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

public class StationServiceTest {
    private StationService servicio;

    @Mock
    private StationRepository stationRepository;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        servicio = new StationService(stationRepository);
    }

    @Test
    public void getAll_returns_customer() {

        Station station1 = new Station();
        Station station2 = new Station();
        Station station3 = new Station();

        List<Station> stations = Arrays.asList(station1, station2, station3);

        Mockito.when(stationRepository.findAll()).thenReturn(stations);

        List<StationDto> result = servicio.getAllStations();
        Assertions.assertEquals(result.size(), 3);
    }
}
