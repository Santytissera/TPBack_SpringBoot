package com.example.station;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StationApplicationTests {

	@Test
	void contextLoads() {
	}

}
