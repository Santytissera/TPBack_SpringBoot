package com.example.station.controllers;

import com.example.station.dtos.StationDto;
import com.example.station.dtos.input.CreateStationDto;
import com.example.station.services.StationService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

public class StationControllerTest {
    private StationController controller;

    @Mock
    private StationService stationService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        controller = new StationController(stationService);
    }

    @Test
    public void getAllStations() {
        StationDto station1 = new StationDto();
        StationDto station2 = new StationDto();
        StationDto station3 = new StationDto();


        List<StationDto> stations = Arrays.asList(station1, station2, station3);

        Mockito.when(stationService.getAllStations()).thenReturn(stations);

        ResponseEntity<List<StationDto>> result = controller.getStations();

        Assertions.assertEquals(result.getStatusCode(), HttpStatusCode.valueOf(200));
        Assertions.assertEquals(result.getBody().size(), 3);
    }

    @Test
    public void createStation_returns_200() {
        CreateStationDto createStationDto = new CreateStationDto();

        StationDto createdStation = new StationDto();

        Mockito.when(stationService.createStation(createStationDto)).thenReturn(createdStation);

        ResponseEntity<StationDto> result = controller.createStation(createStationDto);

        Assertions.assertEquals(result.getStatusCode(), HttpStatusCode.valueOf(200));
        Assertions.assertEquals(createdStation, result.getBody());
    }

    @Test
    public void deleteById_returns_200() {

        Mockito.doNothing().when(stationService).deleteStationById(ArgumentMatchers.anyLong());

        ResponseEntity result = controller.deleteStation(1L);

        Assertions.assertEquals(result.getStatusCode(), HttpStatusCode.valueOf(200));
    }

    @Test
    public void closestToPoint_return_200(){
        StationDto stationDto = new StationDto();
        double latitude = -31.442961123175007;
        double longitude = -64.19409112111947;

        Mockito.when(stationService.getClosestToPoint(longitude,latitude)).thenReturn(stationDto);

        ResponseEntity<StationDto> result = controller.getStations(longitude, latitude );

        Assertions.assertEquals(result.getStatusCode(), HttpStatusCode.valueOf(200));
        Assertions.assertEquals(result.getBody().getLongitude(), -64.19409112111947);
        Assertions.assertEquals(result.getBody().getLatitude(), -31.442961123175007);

    }
}
