package com.example.station.models;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "ESTACIONES")
public class Station {
    @Id()
    @GeneratedValue(generator = "estaciones")
    @TableGenerator(name = "estaciones", table = "sqlite_sequence",
            pkColumnName = "name", valueColumnName = "seq",
            pkColumnValue="ESTACIONES",
            initialValue=1, allocationSize=1)
    @Column(name = "id")
    private Long stationId;


    @Column(name = "Nombre")
    private String name;

    @Column(name = "fecha_hora_creacion")
    private LocalDateTime creationDateTime;

    @Column(name = "latitud")
    private double latitude;

    @Column(name = "longitud")
    private double longitude;

    public Long getStationId() {
        return stationId;
    }

    public void setStationId(Long stationId) {
        this.stationId = stationId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDateTime getCreationDateTime() {
        return creationDateTime;
    }

    public void setCreationDateTime(LocalDateTime creationDateTime) {
        this.creationDateTime = creationDateTime;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
}
