package com.example.station.controllers;

import com.example.station.dtos.StationDto;
import com.example.station.dtos.input.CreateStationDto;
import com.example.station.dtos.input.UpdateStationDto;
import com.example.station.services.StationService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("api/v1/stations")
public class StationController {
    @Autowired
    private StationService _stationService;

    public StationController(StationService stationService) { _stationService = stationService;}

    @GetMapping()
    public ResponseEntity<List<StationDto>> getStations() {
        return ResponseEntity.ok(_stationService.getAllStations());
    }

    @GetMapping("closestToPoint")
    public ResponseEntity<StationDto> getStations(@RequestParam(name = "longitude", required = true) double longitude,
                                                  @RequestParam(name = "latitude", required = true) double latitude) {
        return ResponseEntity.ok(_stationService.getClosestToPoint(longitude, latitude));
    }


    @PostMapping()
    public ResponseEntity<StationDto> createStation(@RequestBody CreateStationDto createStationDto) {
        return ResponseEntity.ok(_stationService.createStation(createStationDto));
    }

    @PutMapping()
    public ResponseEntity<StationDto> updateStation(@RequestBody UpdateStationDto updateStationDto) {
        StationDto updatedStationDto = _stationService.updateStation(updateStationDto);

        if (updatedStationDto != null) {
            return ResponseEntity.ok(updatedStationDto);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("{stationId}")
    public ResponseEntity deleteStation(@PathVariable("stationId") Long id) {
        _stationService.deleteStationById(id);

        return ResponseEntity.ok().build();
    }
}
