package com.example.station.services;

import com.example.station.dtos.StationDto;
import com.example.station.dtos.input.CreateStationDto;
import com.example.station.dtos.input.UpdateStationDto;
import com.example.station.models.Station;
import com.example.station.repositories.StationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class StationService {
    @Autowired
    private StationRepository _stationRepository;

    public StationService(StationRepository stationRepository) { _stationRepository = stationRepository;}

    public List<StationDto> getAllStations() {
        List<Station> stations = _stationRepository.findAll();

        return stations.stream().map(this::convertToDto).collect(Collectors.toList());
    }

    public StationDto getClosestToPoint(double longitude, double latitude) {
        List<Station> stations = _stationRepository.findAll();

        Station closestStationToPoint = stations.get(0);

        for(Station station : stations) {
            double currentClosestStationEuclideanDistanceToPoint = getEuclideanDistance(
                    closestStationToPoint.getLongitude(),
                    longitude,
                    closestStationToPoint.getLatitude(),
                    latitude);
            double stationEuclideanDistanceToPoint = getEuclideanDistance(
                    station.getLongitude(),
                    longitude,
                    station.getLatitude(),
                    latitude
            );
            if(stationEuclideanDistanceToPoint < currentClosestStationEuclideanDistanceToPoint) {
                closestStationToPoint = station;
            }
        }

        return convertToDto(closestStationToPoint);
    }

    private double getEuclideanDistance(double x2, double x1, double y2, double y1){
        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    }

    public StationDto createStation(CreateStationDto createStationDto) {
        Station station = convertToEntity(createStationDto);

        _stationRepository.save(station);

        return convertToDto(station);
    }

    public StationDto updateStation(UpdateStationDto updateStationDto) {
        Optional<Station> existingStation = _stationRepository.findById(updateStationDto.getStationId());

        if(existingStation.isEmpty()) {
            return null;
        }

        existingStation.get().setLatitude(updateStationDto.getLatitude());
        existingStation.get().setLongitude(updateStationDto.getLongitude());
        existingStation.get().setName(updateStationDto.getName());
        existingStation.get().setCreationDateTime(LocalDateTime.now());

        _stationRepository.save(existingStation.get());

        return convertToDto(existingStation.get());
    }

    public void deleteStationById(Long stationId) {
        _stationRepository.deleteById(stationId);
    }

    private StationDto convertToDto(Station station) {
        StationDto stationDto = new StationDto();
        stationDto.setLatitude(station.getLatitude());
        stationDto.setLongitude(station.getLongitude());
        stationDto.setName(station.getName());
        stationDto.setCreationDateTime(station.getCreationDateTime());
        stationDto.setStationId(station.getStationId());
        return stationDto;
    }

    private Station convertToEntity(CreateStationDto createStationDto) {
        Station station = new Station();
        station.setLatitude(createStationDto.getLatitude());
        station.setLongitude(createStationDto.getLongitude());
        station.setName(createStationDto.getName());
        station.setCreationDateTime(LocalDateTime.now());

        return station;
    }
}
