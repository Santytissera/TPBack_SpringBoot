# Integrantes
- Barrera, Pablo
- Gauna, Daniel
- Tissera, Santiago

Url de swagger del servicio Rent
http://localhost:8082/swagger-ui/index.html

Url de swagger del servicio Station
http://localhost:8083/swagger-ui/index.html

Para hacer llamados al gateway y a las APIs usando postman o cualquier otra herramienta hay que setear el bearer token que sirve como 
llave para acceder a la API, a continuacion hay 2 ejemplos de comandos cUrl que se puede ejecutar en la terminal/cmd y con eso obtenemos
una respuesta en formato json, hay que tomar el access token y setearlo como 'Bearer token' antes de hacer el llamado http sino vamos
a obtener un error de autenticacion

# Obtener Token ROL USUARIO
curl --location 'https://labsys.frc.utn.edu.ar/aim/realms/backend-ejemplos/protocol/openid-connect/token' \
--header 'Content-Type: application/x-www-form-urlencoded' --data-urlencode 'client_id=ejemplo_client' --data-urlencode 'client_secret=pass123' \
--data-urlencode 'grant_type=password' --data-urlencode 'username=ejemplo_usuario' --data-urlencode 'password=pass123'

El rol de admin se necesita para hacer POST - PUT - DELETE de stations

# Obtener Token ROL ADMIN
curl --location \
'https://labsys.frc.utn.edu.ar/aim/realms/backend-ejemplos/protocol/openid-connect/token' \
--header 'Content-Type: application/x-www-form-urlencoded' \
--data-urlencode 'client_id=ejemplo_client' \
--data-urlencode 'client_secret=pass123' \
--data-urlencode 'grant_type=password' \
--data-urlencode 'username=ejemplo_admin' \
--data-urlencode 'password=pass123'

![](./imagenes/ejemplo-curl.png)

Y luego ponemos ese token en postman de esta forma

![](./imagenes/ejemplo-postman.png)