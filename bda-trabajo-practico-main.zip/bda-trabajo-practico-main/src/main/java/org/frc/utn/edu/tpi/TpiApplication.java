package org.frc.utn.edu.tpi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TpiApplication.class, args);
	}

}
