package org.frc.utn.edu.tpi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpiApplicationTests {

	@Test
	void contextLoads() {
	}

}
