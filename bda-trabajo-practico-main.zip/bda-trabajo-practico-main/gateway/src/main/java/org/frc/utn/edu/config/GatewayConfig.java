package org.frc.utn.edu.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class GatewayConfig {

    @Bean
    public RouteLocator configurarRutas(RouteLocatorBuilder builder,
                                        @Value("${uri.alquileres}") String uriAlquileres,
                                        @Value("${uri.estaciones}") String uriEstaciones) {
        return builder.routes()
                // Ruteo al Microservicio de Alquileres
                .route(p -> p.path("/api/v1/rents/**").uri(uriAlquileres))
                .route(p -> p.path("/api/v1/fares/**").uri(uriAlquileres))
                // Ruteo al Microservicio de Estaciones
                .route(p -> p.path("/api/v1/stations/**").uri(uriEstaciones))
                .build();

    }

}
