package com.example.rent.models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Optional;

@Entity
@Data
@Table(name = "TARIFAS")
@NoArgsConstructor
@AllArgsConstructor
public class Fare {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "DIA_SEMANA")
    private long dayOfWeek;

    @Column(name = "DIA_MES")
    private Long day;

    @Column(name = "MES")
    private Long month;

    @Column(name = "ANIO")
    private Long year;

    @Column(name = "MONTO_FIJO_ALQUILER")
    private double fixedAmount;

    @Column(name = "MONTO_MINUTO_FRACCION")
    private double fractionMinuteAmount;

    @Column(name = "MONTO_KM")
    private double kilometerAmount;

    @Column(name = "MONTO_HORA")
    private double hourlyAmount;
}
