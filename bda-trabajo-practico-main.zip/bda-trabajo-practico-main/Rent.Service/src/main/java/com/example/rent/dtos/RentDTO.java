package com.example.rent.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RentDTO {

    private Long id;

    private String idCustomer;

    private int state ;

    private Long idRentStation;

    private Long idReturnStation;

    private LocalDateTime rentDateTime;
    private LocalDateTime returnDateTime;

    private Double amount;

    private Long idFare;
}
