package com.example.rent.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FareDTO {

    private Long id;

    private long dayOfWeek;

    private Long day;

    private Long month;

    private String monthName;

    private Long year;

    private double fixedAmount;

    private double fractionMinuteAmount;

    private double kilometerAmount;

    private double hourlyAmount;
}
