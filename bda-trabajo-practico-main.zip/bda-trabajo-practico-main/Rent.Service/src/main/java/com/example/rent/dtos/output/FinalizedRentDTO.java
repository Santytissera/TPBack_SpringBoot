package com.example.rent.dtos.output;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FinalizedRentDTO {

    private Long id;

    private String idCustomer;

    private int state ;

    private Long idRentStation;

    private Long idReturnStation;

    private LocalDateTime rentDateTime;

    private LocalDateTime returnDateTime;

    private String currency;

    private Double amount;

    private Long idFare;

}
