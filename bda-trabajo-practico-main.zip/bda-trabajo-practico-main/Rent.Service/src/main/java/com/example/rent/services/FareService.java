package com.example.rent.services;

import com.example.rent.dtos.FareDTO;
import com.example.rent.dtos.input.CreateFareDTO;
import com.example.rent.dtos.input.UpdateFareDTO;
import com.example.rent.models.Fare;
import com.example.rent.repositories.FareRepository;
import org.springframework.stereotype.Service;

import java.time.Month;
import java.util.List;
import java.util.Optional;

@Service
public class FareService {
    private final FareRepository fareRepository;

    public FareService(FareRepository fareRepository) {
        this.fareRepository = fareRepository;
    }

    public List<FareDTO> getAllFares() {
        List<Fare> fares = fareRepository.findAll();
        return fares.stream().map(this::convertToDto).toList();
    }

    public FareDTO getById(Long fareId) {
        Optional<Fare> existingFare = fareRepository.findById(fareId);
        if (existingFare.isEmpty()){
            return null;
        }
        return convertToDto(existingFare.get());
    }

    public FareDTO createFare(CreateFareDTO createFareDTO) {
        Fare fare = convertToEntity(createFareDTO);
        fareRepository.save(fare);
        return convertToDto(fare);
    }

    public UpdateFareDTO updateFare(Long fareId, UpdateFareDTO updateFareDTO) {
        Optional<Fare> existingFare = fareRepository.findById(fareId);

        if(existingFare.isEmpty()) {
            return null;
        }

        existingFare.get().setId(fareId);
        existingFare.get().setDayOfWeek(updateFareDTO.getDayOfWeek());
        existingFare.get().setDay(updateFareDTO.getDay());
        existingFare.get().setMonth(updateFareDTO.getMonth());
        existingFare.get().setYear(updateFareDTO.getYear());
        existingFare.get().setFixedAmount(updateFareDTO.getFixedAmount());
        existingFare.get().setFractionMinuteAmount(updateFareDTO.getFractionMinuteAmount());
        existingFare.get().setKilometerAmount(updateFareDTO.getKilometerAmount());
        existingFare.get().setHourlyAmount(updateFareDTO.getHourlyAmount());

        fareRepository.save(existingFare.get());
        return convertToUpdatedDTO(existingFare.get());
    }

    public void deleteById(long fareId) {
        fareRepository.deleteById(fareId);
    }

    private Fare convertToEntity(CreateFareDTO fareDTO) {
        Fare fare = new Fare();
        fare.setId(fareDTO.getId());
        fare.setDayOfWeek(fareDTO.getDayOfWeek());
        fare.setDay(fareDTO.getDay());
        fare.setMonth(fareDTO.getMonth());
        fare.setYear(fareDTO.getYear());
        fare.setFixedAmount(fareDTO.getFixedAmount());
        fare.setFractionMinuteAmount(fareDTO.getFractionMinuteAmount());
        fare.setKilometerAmount(fareDTO.getKilometerAmount());
        fare.setHourlyAmount(fareDTO.getHourlyAmount());

        return fare;
    }

    private FareDTO convertToDto(Fare fare) {
        FareDTO fareDTO = new FareDTO();
        fareDTO.setId(fare.getId());
        fareDTO.setDayOfWeek(fare.getDayOfWeek());
        fareDTO.setDay(fare.getDay());
        fareDTO.setMonth(fare.getMonth());
        fareDTO.setMonthName(getMonthName(fare.getMonth()));
        fareDTO.setYear(fare.getYear());
        fareDTO.setFixedAmount(fare.getFixedAmount());
        fareDTO.setFractionMinuteAmount(fare.getFractionMinuteAmount());
        fareDTO.setKilometerAmount(fare.getKilometerAmount());
        fareDTO.setHourlyAmount(fare.getHourlyAmount());
        return fareDTO;
    }

    private UpdateFareDTO convertToUpdatedDTO(Fare fare) {
        UpdateFareDTO updateFareDTO = new UpdateFareDTO();
        updateFareDTO.setId(fare.getId());
        updateFareDTO.setDayOfWeek(fare.getDayOfWeek());
        updateFareDTO.setDay(fare.getDay());
        updateFareDTO.setMonth(fare.getMonth());
        updateFareDTO.setYear(fare.getYear());
        updateFareDTO.setFixedAmount(fare.getFixedAmount());
        updateFareDTO.setFractionMinuteAmount(fare.getFractionMinuteAmount());
        updateFareDTO.setKilometerAmount(fare.getKilometerAmount());
        updateFareDTO.setHourlyAmount(fare.getHourlyAmount());
        return updateFareDTO;
    }

    private String getMonthName(Long monthNumber) {
        if (monthNumber == null) {
            return null;
        }
        return Month.of(monthNumber.intValue()).name();
    }
}
