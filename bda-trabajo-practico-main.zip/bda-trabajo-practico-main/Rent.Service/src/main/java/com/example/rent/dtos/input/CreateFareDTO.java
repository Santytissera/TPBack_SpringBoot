package com.example.rent.dtos.input;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CreateFareDTO {
    private Long id;

    private long dayOfWeek;

    private Long day;

    private Long month;

    private Long year;

    private double fixedAmount;

    private double fractionMinuteAmount;

    private double kilometerAmount;

    private double hourlyAmount;
}
