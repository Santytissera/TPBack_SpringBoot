package com.example.rent.repositories;

import com.example.rent.models.Rent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RentRepository extends JpaRepository<Rent, Long> {
    @Query(value = "select r from Rent r where r.id_Customer = :idCustomer")
    List<Rent> findByCustomer(@Param("idCustomer")String idCustomer);
}
