package com.example.rent.controllers;

import com.example.rent.dtos.RentDTO;
import com.example.rent.dtos.input.CreateRentDTO;
import com.example.rent.dtos.input.UpdateRentDTO;
import com.example.rent.dtos.output.FinalizedRentDTO;
import com.example.rent.dtos.output.RentCostDto;
import com.example.rent.services.RentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("api/v1/rents")
public class RentController {
    private RentService _rentService;

    public RentController(RentService rentService) {
        _rentService = rentService;
    }

    @GetMapping()
    public ResponseEntity<List<RentDTO>> getRents() {
        return ResponseEntity.ok(_rentService.getAllRents());
    }

    @GetMapping("/{idCustomer}")
    public ResponseEntity<List<RentDTO>> getByCustomer(@PathVariable("idCustomer") String idCustomer) {
        List<RentDTO> rents = _rentService.getByCustomer(idCustomer);
        if (rents != null) {
            return ResponseEntity.ok(rents);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping()
    public ResponseEntity<RentDTO> createRent(@RequestBody CreateRentDTO createRentDTO) {
        return ResponseEntity.ok(_rentService.createRent(createRentDTO));
    }

    @GetMapping("{rentId}/getRentCost")
    public ResponseEntity<RentCostDto> getRentCost(@PathVariable("rentId") Long rentId,
                                                   @RequestParam(name = "currency", required = false, defaultValue = "ARS") String currency){
        return ResponseEntity.ok(_rentService.getRentCost(rentId, currency.toUpperCase()));
    }

    @PutMapping("/{id}")
    public ResponseEntity<FinalizedRentDTO> finishRent(@PathVariable("id") Long id,
                                              @RequestParam(name = "currency", required = false, defaultValue = "ARS") String currency,
                                              @RequestBody UpdateRentDTO updateRentDto) {
        FinalizedRentDTO updatedRentDto = _rentService.finishRent(id, updateRentDto, currency);

        if (updatedRentDto != null) {
            return ResponseEntity.ok(updatedRentDto);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity deleteById(@PathVariable("id") Long id){
        _rentService.deleteById(id);

        return ResponseEntity.ok().build();
    }

}
