package com.example.rent.controllers;

import com.example.rent.dtos.FareDTO;
import com.example.rent.dtos.input.CreateFareDTO;
import com.example.rent.dtos.input.UpdateFareDTO;
import com.example.rent.services.FareService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@SecurityRequirement(name="bearerAuth")
@RestController
@RequestMapping("api/v1/fares")
public class FareController {
    private FareService _fareService;

    public FareController(FareService fareService) {
        _fareService = fareService;
    }

    @GetMapping()
    public ResponseEntity<List<FareDTO>> getFares() {
        return ResponseEntity.ok(_fareService.getAllFares());
    }

    @GetMapping("/{id}")
    public ResponseEntity<FareDTO> getFareById(@PathVariable(name = "id") Long fareId) {
        return ResponseEntity.ok(_fareService.getById(fareId));
    }
    @PostMapping()
    public ResponseEntity<FareDTO> createFare(@RequestBody CreateFareDTO createFareDTO) {
        return ResponseEntity.ok(_fareService.createFare(createFareDTO));
    }

    @PutMapping("/{id}")
    public ResponseEntity<UpdateFareDTO> updateFare(@PathVariable("id") Long id,
                                              @RequestBody UpdateFareDTO updateFareDTO) {
        UpdateFareDTO updatedFareDTO = _fareService.updateFare(id, updateFareDTO);
        if (updatedFareDTO != null) {
            return ResponseEntity.ok(updatedFareDTO);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity deleteById(@PathVariable("id") Long id){
        _fareService.deleteById(id);

        return ResponseEntity.ok().build();
    }
}
