package com.example.rent.services;

import com.example.rent.dtos.RentDTO;
import com.example.rent.dtos.input.CreateRentDTO;
import com.example.rent.dtos.input.UpdateRentDTO;
import com.example.rent.dtos.output.FinalizedRentDTO;
import com.example.rent.dtos.output.RentCostDto;
import com.example.rent.models.Fare;
import com.example.rent.models.Rent;
import com.example.rent.repositories.FareRepository;
import com.example.rent.repositories.RentRepository;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;
import org.json.JSONObject;

@Service
public class RentService {
    private final RentRepository rentRepository;
    private final FareRepository fareRepository;

    public RentService(RentRepository rentRepository, FareRepository fareRepository) {
        this.rentRepository = rentRepository;
        this.fareRepository = fareRepository;
    }

    public List<RentDTO> getAllRents() {
        List<Rent> rents = rentRepository.findAll();
        return rents.stream().map(this::convertToDto).toList();
    }

    public List<RentDTO> getByCustomer(String idCustomer) {
        List<Rent> rents = rentRepository.findByCustomer(idCustomer);
        return rents.stream().map(this::convertToDto).toList();
    }

    public RentDTO createRent(CreateRentDTO createRentDto) {
        Rent rent = convertToEntity(createRentDto);

        LocalDateTime currentDateTime = LocalDateTime.now();

        rent.setRentDateTime(currentDateTime);
        rent.setState(1);
        rent.setId_RentStation(createRentDto.getStationId());

        List<Fare> fares = fareRepository.findAll();

        Optional<Fare> fareWithDiscount = fares.stream()
                .filter(fare -> fare.getDay() != null &&
                        fare.getMonth() != null &&
                        fare.getYear() != null &&
                        fare.getDay().intValue() == currentDateTime.getDayOfMonth() &&
                        fare.getMonth().intValue() == currentDateTime.getMonthValue() &&
                        fare.getYear().intValue() == currentDateTime.getYear())
                .findFirst();

        if (fareWithDiscount.isPresent()){
            rent.setIdFare(fareWithDiscount.get().getId());
        }
        else {
            // 1 - Monday -> 7 - Sunday
            int todayDayOfWeek = currentDateTime.getDayOfWeek().getValue();
            Optional<Fare> regularDayOfWeekFare = fares.stream()
                    .filter(fare -> fare.getDayOfWeek() == todayDayOfWeek)
                    .findFirst();
            rent.setIdFare(regularDayOfWeekFare.get().getId());
        }

        rentRepository.save(rent);

        return convertToDto(rent);
    }

    public RentCostDto getRentCost(Long rentId, String currency) {
        double totalCostInArgentineanPeso = getRentTotalCostInArgentineanPesos(rentId);

        double totalAmountInDesiredCurrency = getTotalAmountInDesiredCurrency(currency, totalCostInArgentineanPeso);

        RentCostDto rentCostDto = new RentCostDto();
        rentCostDto.setCurreny(currency);
        rentCostDto.setTotalAmount(totalAmountInDesiredCurrency);

        return rentCostDto;
    }

    private double getTotalAmountInDesiredCurrency(String currency, double totalCost) {
        if(currency.equals("ARS")){
            return totalCost;
        }

        String currenciesValues = getCurrenciesFromExternalService();

        // Parsear la respuesta JSON
        JSONObject currenciesValuesJsonObject = new JSONObject(currenciesValues);

        // Acceder al objeto de tasas (rates)
        JSONObject rates = currenciesValuesJsonObject.getJSONObject("rates");

        // Acceder a una tasa específica (por ejemplo, la tasa para "EUR")
        double rateForArgentinePeso = rates.getDouble("ARS");
        double rateForDesiredCurrency = rates.getDouble(currency);

        double totalAmountInDollars = totalCost / rateForArgentinePeso;
        double totalAmountInDesiredCurrency = totalAmountInDollars * rateForDesiredCurrency;
        return totalAmountInDesiredCurrency;
    }

    private double getRentTotalCostInArgentineanPesos(Long rentId) {
        Rent rent = rentRepository.getReferenceById(rentId);

        LocalDateTime returnDateTime = rent.getRentDateTime();
        LocalDateTime currentDateTime = LocalDateTime.now();

        long fareId = rent.getIdFare();
        Fare fare = fareRepository.getReferenceById(fareId);

        long minutes = ChronoUnit.MINUTES.between(returnDateTime, currentDateTime);
        double totalCost = fare.getFixedAmount();
        if (minutes < 31) {
            double fareFractionMinuteAmount = fare.getFractionMinuteAmount();
            totalCost += fareFractionMinuteAmount * minutes;
        }
        else {
            double fareHourlyAmount = fare.getHourlyAmount();
            long hours = minutes/60;
            totalCost += fareHourlyAmount * hours;
        }
        return totalCost;
    }

    private String getCurrenciesFromExternalService() {
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url("https://openexchangerates.org/api/latest.json?app_id=c44e81fd8d934c5285c426a402297101&base=USD")
                .get()
                .addHeader("accept", "application/json")
                .build();

        try {
            Response response = client.newCall(request).execute();

            return response.body().string();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public FinalizedRentDTO finishRent(Long id, UpdateRentDTO updateRentDto, String currency) {
        Optional<Rent> existingRent = rentRepository.findById(id);

        if(existingRent.isEmpty()) {
            return null;
        }

        double totalAmountInArgentinianPesos = getRentTotalCostInArgentineanPesos(id);

        existingRent.get().setId_ReturnStation(updateRentDto.getIdReturnStation());
        existingRent.get().setId(id);
        existingRent.get().setState(2);
        existingRent.get().setAmount(totalAmountInArgentinianPesos);
        existingRent.get().setReturnDateTime(LocalDateTime.now());

        rentRepository.save(existingRent.get());

        return convertToFinalizedRentDto(existingRent.get(), currency);
    }

    public void deleteById(long rentId) {
        rentRepository.deleteById(rentId);
    }

    private RentDTO convertToDto(Rent rent){
        RentDTO rentDTO = new RentDTO();
        rentDTO.setId(rent.getId());
        rentDTO.setIdCustomer(rent.getId_Customer());
        rentDTO.setState(rent.getState());
        rentDTO.setIdReturnStation(rent.getId_ReturnStation());
        rentDTO.setIdRentStation(rent.getId_RentStation());
        rentDTO.setRentDateTime(rent.getRentDateTime());
        rentDTO.setRentDateTime(rent.getRentDateTime());
        rentDTO.setAmount(rent.getAmount());
        rentDTO.setIdFare(rent.getIdFare());
        return rentDTO;

    }

    private FinalizedRentDTO convertToFinalizedRentDto(Rent rent, String currency){
        FinalizedRentDTO fianlizedRentDto = new FinalizedRentDTO();
        fianlizedRentDto.setId(rent.getId());
        fianlizedRentDto.setIdCustomer(rent.getId_Customer());
        fianlizedRentDto.setState(rent.getState());
        fianlizedRentDto.setIdReturnStation(rent.getId_ReturnStation());
        fianlizedRentDto.setIdRentStation(rent.getId_RentStation());
        fianlizedRentDto.setRentDateTime(rent.getRentDateTime());
        fianlizedRentDto.setReturnDateTime(rent.getRentDateTime());
        double totalAmountInDesiredCurrency = getTotalAmountInDesiredCurrency(currency, rent.getAmount());
        fianlizedRentDto.setAmount(totalAmountInDesiredCurrency);
        fianlizedRentDto.setCurrency(currency);
        fianlizedRentDto.setIdFare(rent.getIdFare());
        return fianlizedRentDto;

    }

    private Rent convertToEntity(CreateRentDTO createRentDto){
        Rent rent = new Rent();
        rent.setId_Customer(createRentDto.getCustomerId());
        return rent;

    }
}
