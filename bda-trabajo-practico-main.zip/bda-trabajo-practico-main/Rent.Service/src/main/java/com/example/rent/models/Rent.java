package com.example.rent.models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Date;


@Entity
@Data
@Table(name = "ALQUILERES")
@NoArgsConstructor
@AllArgsConstructor
public class Rent {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;
    @Column(name = "ID_CLIENTE")
    private String id_Customer;
    @Column(name = "ESTADO")
    private int state ;
    @Column(name = "ESTACION_RETIRO")
    private Long id_RentStation;
    @Column(name = "ESTACION_DEVOLUCION")
    private Long id_ReturnStation;
    @Column(name = "FECHA_HORA_RETIRO")
    private LocalDateTime rentDateTime;
    @Column(name = "FECHA_HORA_DEVOLUCION")
    private LocalDateTime returnDateTime;
    @Column(name = "MONTO")
    private Double amount;
    @Column(name = "ID_TARIFA")
    private Long idFare;

}
