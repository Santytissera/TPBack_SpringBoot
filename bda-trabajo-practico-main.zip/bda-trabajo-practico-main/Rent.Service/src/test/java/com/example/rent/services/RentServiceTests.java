package com.example.rent.services;

import com.example.rent.dtos.RentDTO;
import com.example.rent.models.Rent;
import com.example.rent.repositories.FareRepository;
import com.example.rent.repositories.RentRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

public class RentServiceTests {
    private RentService servicio;

    @Mock
    private RentRepository rentRepository;
    @Mock
    private FareRepository fareRepository;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        servicio = new RentService(rentRepository, fareRepository);
    }

    @Test
    public void getAll_returns_customer() {

        Rent rent1 = new Rent();
        Rent rent2 = new Rent();
        Rent rent3 = new Rent();

        List<Rent> rents = Arrays.asList(rent1, rent2, rent3);

        Mockito.when(rentRepository.findAll()).thenReturn(rents);

        List<RentDTO> result = servicio.getAllRents();
        Assertions.assertEquals(result.size(), 3);
    }

    @Test
    public void findByCustomer_returns_customer() {
        String customerId = "testCustomerId";

        Rent rent = new Rent();
        rent.setId_Customer(customerId);
        Mockito.when(rentRepository.findByCustomer(customerId)).thenReturn(List.of(rent));

        List<RentDTO> result = servicio.getByCustomer(customerId);
        Assertions.assertEquals(result.get(0).getIdCustomer(), rent.getId_Customer());
    }

    @Test
    public void findByCustomer_delete_rent() {
        Long rentIdToDelete = 2L;

        Rent rent = new Rent();
        rent.setId(rentIdToDelete);
        Mockito.doNothing().when(rentRepository).deleteById(ArgumentMatchers.anyLong());

        servicio.deleteById(rentIdToDelete);

        Mockito.verify(rentRepository, Mockito.times(1)).deleteById(rentIdToDelete);
    }
}
