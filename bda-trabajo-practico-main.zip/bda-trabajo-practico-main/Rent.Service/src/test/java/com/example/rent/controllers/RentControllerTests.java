package com.example.rent.controllers;

import com.example.rent.dtos.RentDTO;
import com.example.rent.dtos.input.CreateRentDTO;
import com.example.rent.dtos.input.UpdateRentDTO;
import com.example.rent.dtos.output.FinalizedRentDTO;
import com.example.rent.dtos.output.RentCostDto;
import com.example.rent.models.Rent;
import com.example.rent.repositories.FareRepository;
import com.example.rent.repositories.RentRepository;
import com.example.rent.services.RentService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

public class RentControllerTests {
    private RentController controller;

    @Mock
    private RentService rentService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        controller = new RentController(rentService);
    }

    @Test
    public void getAll_returns_customer() {
        RentDTO rent1 = new RentDTO();
        RentDTO rent2 = new RentDTO();
        RentDTO rent3 = new RentDTO();

        List<RentDTO> rents = Arrays.asList(rent1, rent2, rent3);

        Mockito.when(rentService.getAllRents()).thenReturn(rents);

        ResponseEntity<List<RentDTO>> result = controller.getRents();

        Assertions.assertEquals(result.getStatusCode(), HttpStatusCode.valueOf(200));
        Assertions.assertEquals(result.getBody().size(), 3);
    }

    @Test
    public void getByCustomer_returns_rents() {
        String customerId = "testCustomerId";

        RentDTO rent1 = new RentDTO();
        RentDTO rent2 = new RentDTO();

        List<RentDTO> rents = Arrays.asList(rent1, rent2);

        Mockito.when(rentService.getByCustomer(customerId)).thenReturn(rents);

        ResponseEntity<List<RentDTO>> result = controller.getByCustomer(customerId);

        Assertions.assertEquals(result.getStatusCode(), HttpStatusCode.valueOf(200));
        Assertions.assertEquals(result.getBody().size(), 2);
    }

    @Test
    public void getByCustomer_returns_not_found_when_no_rents_returned() {
        String customerId = "testCustomerId";

        Mockito.when(rentService.getByCustomer(customerId)).thenReturn(null);

        ResponseEntity<List<RentDTO>> result = controller.getByCustomer(customerId);

        Assertions.assertEquals(result.getStatusCode(), HttpStatusCode.valueOf(404));
    }

    @Test
    public void createRent_returns_200() {
        CreateRentDTO createRentDTO = new CreateRentDTO();

        RentDTO createdRent = new RentDTO();

        Mockito.when(rentService.createRent(createRentDTO)).thenReturn(createdRent);

        ResponseEntity<RentDTO> result = controller.createRent(createRentDTO);

        Assertions.assertEquals(result.getStatusCode(), HttpStatusCode.valueOf(200));
        Assertions.assertEquals(createdRent, result.getBody());
    }

    @Test
    public void getRentCost_returns_200() {
        RentCostDto rentCostDto = new RentCostDto();
        rentCostDto.setTotalAmount(244);
        rentCostDto.setCurreny("USD");

        Mockito.when(rentService.getRentCost(ArgumentMatchers.anyLong(), ArgumentMatchers.anyString())).thenReturn(rentCostDto);

        ResponseEntity<RentCostDto> result = controller.getRentCost(1L, "USD");

        Assertions.assertEquals(result.getStatusCode(), HttpStatusCode.valueOf(200));
        Assertions.assertEquals(result.getBody().getCurreny(), "USD");
        Assertions.assertEquals(result.getBody().getTotalAmount(), 244);
    }

    @Test
    public void finishRent_finalizes_rent() {
        FinalizedRentDTO finalizedRentDTO = new FinalizedRentDTO();
        UpdateRentDTO updateRentDTO = new UpdateRentDTO();

        Mockito.when(rentService.finishRent(ArgumentMatchers.anyLong(), ArgumentMatchers.any(), ArgumentMatchers.anyString())).thenReturn(finalizedRentDTO);

        ResponseEntity<FinalizedRentDTO> result = controller.finishRent(1L, "USD", updateRentDTO);

        Assertions.assertEquals(result.getStatusCode(), HttpStatusCode.valueOf(200));
        Assertions.assertEquals(result.getBody(), finalizedRentDTO);
    }

    @Test
    public void finishRent_returns_not_found() {
        FinalizedRentDTO finalizedRentDTO = new FinalizedRentDTO();
        UpdateRentDTO updateRentDTO = new UpdateRentDTO();

        Mockito.when(rentService.finishRent(ArgumentMatchers.anyLong(), ArgumentMatchers.any(), ArgumentMatchers.anyString())).thenReturn(null);

        ResponseEntity<FinalizedRentDTO> result = controller.finishRent(1L, "USD", updateRentDTO);

        Assertions.assertEquals(result.getStatusCode(), HttpStatusCode.valueOf(404));
        Assertions.assertEquals(result.getBody(), null);
    }

    @Test
    public void deleteById_returns_200() {

        Mockito.doNothing().when(rentService).deleteById(ArgumentMatchers.anyLong());

        ResponseEntity result = controller.deleteById(1L);

        Assertions.assertEquals(result.getStatusCode(), HttpStatusCode.valueOf(200));
    }


}
